/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pvzsergioycesar;

/**
 *
 * @author cesar
 */
public class Caracubo extends Zombie{

    private int dano = 1;
    private int resistencia = 8;
    
    public Caracubo(int fila, int columna, int turnoCreacion, String id) {
        super(fila, columna, turnoCreacion, id);
        this.dano = dano;
        this.resistencia = resistencia;
    }

    public int getDano() {
        return dano;
    }

    public void setDano(int dano) {
        this.dano = dano;
    }

    public int getResistencia() {
        return resistencia;
    }

    public void setResistencia(int resistencia) {
        this.resistencia = resistencia;
    }

    public String representacion() {

        return "ZC" + String.valueOf(getResistencia());
    }
    
    
    @Override
    public void recibirDano() {
        int danno = 1;
        setResistencia(getResistencia()-danno);
        if (getResistencia() < 0) {
            setResistencia(0);
        }
    }
    
  
}
