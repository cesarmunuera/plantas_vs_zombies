/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pvzsergioycesar;

/**
 * @author César Munuera Pérez y Sergio Salmerón González
 */
/**
 * Esta clase es la Zombie, que procede de la clase Ítem
 */
public abstract class Zombie extends Item {
     private int dano = 1;
    private int resistencia = 5;
    
    /**
     * @param fila Fila donde se encuentra el Zombie
     * @param columna Columna donde se encuentra el Zombie
     * @param turnoCreacion
     * @param id Identificador del elemento el Zombie
     */
    public Zombie(int fila, int columna, int turnoCreacion, String id) {
        super(fila, columna, turnoCreacion, id);
        this.resistencia = resistencia;
        this.dano = dano;
    }

    public int getDano() {
        return dano;
    }

    public void setDano(int dano) {
        this.dano = dano;
    }

    public int getResistencia() {
        return resistencia;
    }

    public void setResistencia(int resistencia) {
        this.resistencia = resistencia;
    }
    
    
    /**
     * @return Representacion nos retorna un String con el Zombie deseado y su resistencia
     */
    /**
     * Representacion nos retorna un String con el Zombie deseado y su resistencia
     */
    public String representacion() {

        return "Z" + String.valueOf(getResistencia());
    }

    
    /**
    * Este metodo calcula el daño que reciben los zombies
    */
    @Override
    public abstract void recibirDano();
    
}
