/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pvzsergioycesar;

/**
 * @author César Munuera Pérez y Sergio Salmerón González
 */
/**
 * En esta clase se realiza el tratamiento de las excepciones
 */
public class ExcepcionPlanta extends Exception {

    public ExcepcionPlanta(String message) {
        super(message);
    }
}