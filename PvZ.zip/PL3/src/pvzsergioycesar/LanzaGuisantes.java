/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pvzsergioycesar;

/**
 * @author César Munuera Pérez y Sergio Salmerón González
 */
/**
 * Esta clase hace referencia al objeto Lanzaguisantes, de tipo Planta
 */
public class LanzaGuisantes extends Planta {
    private int dano = 1;
    private int resistencia = 3;
    private int coste = 50;

    /**
     * @param fila Fila donde se encuentra el lanzaguisantes
     * @param columna Columna donde se encuentra el lanzaguisantes
     * @param turnoCreacion Turno en el que se creó la planta
     * @param id Identificador de el lanzaguisantes
     */
    public LanzaGuisantes(int fila, int columna,int turnoCreacion, String id) {
        super(fila, columna, turnoCreacion, id);
        this.resistencia = resistencia;
        this.coste = coste;
        this.dano = dano;
    }

    /**
     * @return Coste
     */
    public int getCoste() {
        return coste;
    }

    /**
     * @param coste
     */
    public void setCoste(int coste) {
        this.coste = coste;
    }

    public int getResistencia() {
        return resistencia;
    }

    
    public void setResistencia(int resistencia) {
        this.resistencia = resistencia;
    }
    
    /**
     * @return Representacion nos retorna un String con el lanzaguisantes deseado y su resistencia
     */
    /**
     * Representacion nos retorna un String con la planta deseada y su resistencia
     */
    public String representacion() {

        return "L" + String.valueOf(getResistencia());
    }

    
    /**
    * Este metodo calcula el daño que recibe el lanzaguisantes
    */
    @Override
    public void recibirDano() {
        int danno = 1;
        setResistencia(getResistencia() - danno);
        if (getResistencia() < 0) {
            setResistencia(0);
        }
    }   
}