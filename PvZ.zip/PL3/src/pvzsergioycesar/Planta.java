/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pvzsergioycesar;

/**
 * @author César Munuera Pérez y Sergio Salmerón González
 */
/**
 * Esta clase hace referencia al objeto Planta, de tipo Ítem
 */
public abstract class Planta extends Item {
    /**
     * @param fila Fila donde se encuentra la planta
     * @param columna Columna donde se encuentra la planta
     * @param turnoCreacion Turno en el que se creó la planta
     * @param id Identificador de la planta
     */
    
    public Planta(int fila, int columna, int turnoCreacion,  String id) {
        super(fila, columna, turnoCreacion , id);
    }

    /**
     * @return Representacion nos retorna un String con la planta deseada y su resistencia
     */
    /**
     *Representacion nos retorna un String con la planta deseada y su resistencia
     */
    
    public String representacion() {

        return "P" + String.valueOf(getResistencia());
    }
    
    /**
    * Este metodo calcula el daño que reciben las plantas
    */
    @Override
    public abstract void recibirDano();
    
}
