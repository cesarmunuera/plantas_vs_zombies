/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pvzsergioycesar;

/**
 * @author César Munuera Pérez y Sergio Salmerón González
 */
/**
 * Esta clase hace referencia a cada objeto en general, es la clase padre
 */
public abstract class Item {
    private int resistencia, fila, columna, turnoCreacion;
    private int dano;
    private String id; 

    /**
     * @param fila Fila donde se encuentra el item
     * @param columna Columna donde se encuentra el elemento
     * @param turnoCreacion Turno en el que se creó la planta
     * @param id Identificador del elemento
     */
    public Item(int fila, int columna, int turnoCreacion, String id) {
        this.fila = fila;
        this.columna = columna;
        this.turnoCreacion = turnoCreacion;
        this.id = id;
    }

    
    /**
     * @return resistencia
     */
    public int getResistencia() {
        return resistencia;
    }

    /**
     * @param resistencia 
     */
    public void setResistencia(int resistencia) {
        this.resistencia = resistencia;
    }

    /**
     * @return fila
     */
    public int getFila() {
        return fila;
    }

    /**
     * @param fila
     */
    public void setFila(int fila) {
        this.fila = fila;
    }

    /**
     * @return Columna
     */
    public int getColumna() {
        return columna;
    }

    /**
     * @param columna
     */
    public void setColumna(int columna) {
        this.columna = columna;
    }

    /**
     * @return Turno de Creación
     */
    public int getTurnoCreacion() {
        return turnoCreacion;
    }

    /**
     * @param turnoCreacion
     */
    public void setTurnoCreacion(int turnoCreacion) {
        this.turnoCreacion = turnoCreacion;
    }
    

    /**
     * @return Daño
     */
    public int getDano() {
        return dano;
    }

    /**
     * @param dano
     */
    public void setDano(int dano) {
        this.dano = dano;
    }

    /**
     * @return Id
     */
    public String getId() {
        return id;
    }

    /**
     * @param id
     */
    public void setId(String id) {
        this.id = id;
    }
    
    
    /**
     * @param i
     * @return Representacion nos retorna un String con el objeto deseado y su resistencia
     */
    /**
     * Representacion nos retorna un String con la planta deseada y su resistencia
     */
    public String representacion (Item i){
        
        return "I"+String.valueOf(this.resistencia);
    }
    
    /**
     * Funcion que calcula el daño que recibe un elemento
     */
    public abstract void recibirDano();
 
}