/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pvzsergioycesar;

/**
 *
 * @author cesar
 */
public class Nuez extends Planta{

    private int resistencia = 10;
    private int coste = 50; 
    private int dano = 0;

    public Nuez(int fila, int columna,int turnoCreacion, String id) {
        super(fila, columna, turnoCreacion, id);
        this.resistencia = resistencia;
        this.coste = coste;
        this.dano = dano;
    }

    public int getResistencia() {
        return resistencia;
    }

    public void setResistencia(int resistencia) {
        this.resistencia = resistencia;
    }

    public int getCoste() {
        return coste;
    }

    public void setCoste(int coste) {
        this.coste = coste;
    }
    
    
    public String representacion() {

        return "N" + String.valueOf(getResistencia());
    }
    
    
    
    
    @Override
    public void recibirDano() {
        int danno = 1;
        setResistencia(getResistencia() - danno);
        if (getResistencia() < 0) {
            setResistencia(0);
        }
    }
    
}
