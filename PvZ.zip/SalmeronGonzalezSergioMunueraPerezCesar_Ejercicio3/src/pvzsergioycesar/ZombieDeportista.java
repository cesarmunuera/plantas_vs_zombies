/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pvzsergioycesar;

/**
 * @author César Munuera Pérez y Sergio Salmerón González
 */
/**
 * Esta clase es Zombie Deportista, que procede de la clase Zombie
 */
public class ZombieDeportista extends Zombie {

    private int dano = 1;
    private int resistencia = 2;

    /**
     * @param fila Fila donde se encuentra el Zombie
     * @param columna Columna donde se encuentra el Zombie
     * @param turnoCreacion Turno donde se creó el Zombie
     * @param id Identificador del elemento el Zombie
     */
    public ZombieDeportista(int fila, int columna, int turnoCreacion, String id) {
        super(fila, columna, turnoCreacion, id);
        this.dano = dano;
        this.resistencia = resistencia;
    }

    public int getDano() {
        return dano;
    }

    public void setDano(int dano) {
        this.dano = dano;
    }

    public int getResistencia() {
        return resistencia;
    }

    public void setResistencia(int resistencia) {
        this.resistencia = resistencia;
    }

    /**
     * @return Representacion nos retorna un String con el Zombie Deportista
     * deseado y su resistencia
     */
    /**
     * Representacion nos retorna un String con el Zombie deseado y su
     * resistencia
     * @return 
     */
    public String representacion() {

        return "ZD" + String.valueOf(getResistencia());
    }

    /**
    * Este metodo calcula el daño que recibe la clase Zombie Deportista
    */
    @Override
    public void recibirDano() {
        int danno = 1;
        setResistencia(getResistencia() - danno);
        if (getResistencia() < 0) {
            setResistencia(0);
        }
    }
    
}