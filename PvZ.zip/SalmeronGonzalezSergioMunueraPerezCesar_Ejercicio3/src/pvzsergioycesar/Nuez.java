/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pvzsergioycesar;

/**
 * @author César Munuera Pérez y Sergio Salmerón González
 */
/**
 * Esta clase hace referencia al objeto Nuez, de tipo Planta
 */
public class Nuez extends Planta{

    private int resistencia = 10;
    private int coste = 50; 
    private int dano = 0;

    /**
     * @param fila Fila donde se encuentra el girasol
     * @param columna Columna donde se encuentra el girasol
     * @param turnoCreacion Turno en el que se creó la planta
     * @param id Identificador de el girasol
     */
    public Nuez(int fila, int columna,int turnoCreacion, String id) {
        super(fila, columna, turnoCreacion, id);
        this.resistencia = resistencia;
        this.coste = coste;
        this.dano = dano;
    }

    public int getResistencia() {
        return resistencia;
    }

    public void setResistencia(int resistencia) {
        this.resistencia = resistencia;
    }

    /**
     * @return Coste de la Nuez
     */
    public int getCoste() {
        return coste;
    }

    /**
     * @param coste
     */
    public void setCoste(int coste) {
        this.coste = coste;
    }
    
    /**
     * @return Representacion nos retorna un String con la nuez deseado y su resistencia
     */
    /**
     * Representacion nos retorna un String con la nuez deseada y su resistencia
     */
    public String representacion() {

        return "N" + String.valueOf(getResistencia());
    }
    
    /**
    * Este metodo calcula el daño que recibe la clase girasol
    */
    @Override
    public void recibirDano() {
        int danno = 1;
        setResistencia(getResistencia() - danno);
        if (getResistencia() < 0) {
            setResistencia(0);
        }
    }
    
}
