/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pvzsergioycesar;

/**
 * @author César Munuera Pérez y Sergio Salmerón González
 */
/**
 * Esta clase hace referencia al objeto Girasol, de tipo Planta
 */
public class Girasol extends Planta {
    private int numSoles = 10;
    private int resistencia = 1;
    private int coste = 20;
    private int turnoCreacion;
    
    /**
     * @param fila Fila donde se encuentra el girasol
     * @param columna Columna donde se encuentra el girasol
     * @param turnoCreacion Turno en el que se creó la planta
     * @param id Identificador de el girasol
     */
    public Girasol(int fila, int columna, int turnoCreacion, String id) {
        super(fila, columna, turnoCreacion, id);
        this.resistencia = resistencia;
        this.coste = coste;
    }
    
    /**
     * @return Turno de Creación
     */
    public int getTurnoCreacion() {
        return turnoCreacion;
    }

    /**
     * @param turnoCreacion
     */
    public void setTurnoCreacion(int turnoCreacion) {
        this.turnoCreacion = turnoCreacion;
    }

    /**
     * @return Coste
     */
    public int getCoste() {
        return coste;
    }

    /**
     * @param coste
     */
    public void setCoste(int coste) {
        this.coste = coste;
    }

    /**
     * @return Número de Soles
     */
    public int getNumSoles() {
        return numSoles;
    }

    /**
     * @param numSoles
     */
    public void setNumSoles(int numSoles) {
        this.numSoles = numSoles;
    }

    public int getResistencia() {
        return resistencia;
    }

    public void setResistencia(int resistencia) {
        this.resistencia = resistencia;
    }
    
    
    /**
     * @param turno
     * @return Soles generados
     */
    /*
    * Funcion que genera soles cada dos turnos, de los girasoles plantados
    */
    public int generarSoles(int turno) {
        if ((turno - getTurnoCreacion())%2 == 0){
            return 10;
        }else{
            return 0;
        } 
    }
    
    /**
     * @return Representacion nos retorna un String con el girasol deseado y su resistencia
     */
    /**
     * Representacion nos retorna un String con el girasol deseado y su resistencia
     */
    public String representacion() {

        return "G" + String.valueOf(getResistencia());
    }

    @Override
    public String toString() {
        return "Girasol{" + "numSoles=" + numSoles + '}';
    }
    
    /**
    * Este metodo calcula el daño que recibe la clase girasol
    */
    @Override
    public void recibirDano() {
        int danno = 1;
        setResistencia(getResistencia()-danno);
        if (getResistencia() < 0) {
            setResistencia(0);
        }
    }
    
}