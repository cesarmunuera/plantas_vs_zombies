/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pvzsergioycesar;

import java.util.ArrayList;
import java.util.Random;

/**
 * @author César Munuera Pérez y Sergio Salmerón González
 */
/**
 * Es la clase Tablero, donde encontramos la mayor parte de los metodos. Es de
 * las más importantes
 */
public class Tablero {

    private Item[][] tablero;
    private String dificultad;
    private static int filas, columnas, zombiesRestantes, turnosSinZombies, contadorZombies = 0, limiteTurnos = 30, zombiesvivos;

    /**
     * @param filas Filas totales del tablero
     * @param columnas Columnas totales del tablero
     * @param dificultad Dificultad del juego
     */
    /*
    * La clase tablero realiza una gran cantidad de operaciones, especificadas a continuación.
     */
    public Tablero(int filas, int columnas, String dificultad) {
        this.tablero = new Item[filas][columnas];
        this.dificultad = dificultad;
        this.filas = filas;
        this.columnas = columnas;

        if (dificultad.equals("BAJA")) {
            this.zombiesRestantes = 5;
            this.zombiesvivos = 5;
            this.turnosSinZombies = 10;
        } else if (dificultad.equals("MEDIA")) {
            this.zombiesRestantes = 15;
            this.zombiesvivos = 15;
            this.turnosSinZombies = 7;
        } else if (dificultad.equals("ALTA")) {
            this.zombiesRestantes = 25;
            this.zombiesvivos = 25;
            this.turnosSinZombies = 5;
        } else if (dificultad.equals("IMPOSIBLE")) {
            this.zombiesRestantes = 50;
            this.zombiesvivos = 50;
            this.turnosSinZombies = 5;
        }
    }

    /**
     * @return Zombies Restantes
     */
    public static int getZombiesRestantes() {
        return zombiesRestantes;
    }

    /**
     * @param zombiesRestantes
     */
    public static void setZombiesRestantes(int zombiesRestantes) {
        Tablero.zombiesRestantes = zombiesRestantes;
    }

    /**
     * @return Turnos sin Zombies
     */
    public static int getTurnosSinZombies() {
        return turnosSinZombies;
    }

    /**
     * @param turnosSinZombies
     */
    public static void setTurnosSinZombies(int turnosSinZombies) {
        Tablero.turnosSinZombies = turnosSinZombies;
    }

    /**
     * @return Recuento de Zombies
     */
    public static int getContadorZombies() {
        return contadorZombies;
    }

    /**
     * @param contadorZombies
     */
    public static void setContadorZombies(int contadorZombies) {
        Tablero.contadorZombies = contadorZombies;
    }

    /**
     * @return Zombies vivos
     */
    public static int getZombiesvivos() {
        return zombiesvivos;
    }

    /**
     * @param zombiesvivos
     */
    public static void setZombiesvivos(int zombiesvivos) {
        Tablero.zombiesvivos = zombiesvivos;
    }

    /**
     * @return Tablero
     */
    public Item[][] getTablero() {
        return tablero;
    }

    /**
     * @param tablero
     */
    public void setTablero(Item[][] tablero) {
        this.tablero = tablero;
    }

    /**
     * @return Dificultad
     */
    public String getDificultad() {
        return dificultad;
    }

    /**
     * @param dificultad
     */
    public void setDificultad(String dificultad) {
        this.dificultad = dificultad;
    }

    /**
     * @return Filas
     */
    public static int getFilas() {
        return filas;
    }

    /**
     * @param filas
     */
    public void setFilas(int filas) {
        this.filas = filas;
    }

    /**
     * @return Columnas
     */
    public static int getColumnas() {
        return columnas;
    }

    /**
     * @param columnas
     */
    public void setColumnas(int columnas) {
        this.columnas = columnas;
    }

    /**
     * @return Límite de turnos
     */
    public static int getLimiteTurnos() {
        return limiteTurnos;
    }

    /**
     * @param limiteTurnos
     */
    public static void setLimiteTurnos(int limiteTurnos) {
        Tablero.limiteTurnos = limiteTurnos;
    }

    /**
     * @param planta
     * @throws Exception
     */
    /**
     * Este metodo nos coloca la planta donde indiquemos.Almacena su posición,
     * comprueba si la intentas poner en un sitio incorrecto.Tambien la guarda
     * en la lista de su tipo.
     */
    public void ponerPlanta(Planta planta) throws ExcepcionPlanta {
        int filaplanta = planta.getFila(), columnaplanta = planta.getColumna(); // Almacena la posición
        if (columnaplanta == getColumnas() - 1) { // no se pueden poner plantas al final
            throw new ExcepcionPlanta("No se pueden poner plantas al final");
        }
        if (getTablero()[filaplanta][columnaplanta] == null) { //Si no está ocupada esa casilla
            getTablero()[filaplanta][columnaplanta] = planta;
            // Coloca la planta en la posición especificada de la matriz
        } else { // Por si el usuario desea colocar una planta encima de otra
            throw new ExcepcionPlanta("La casilla está ocupada");
        }
    }

    /**
     * @param turno
     */
    /**
     * El metodo generarZombie comienza comprobando la disponibilidad de las
     * casillas de la última columna y la cantidad restante de zombies. Nos
     * genera un numero random de zombies (menor a los que quedan por salir) y
     * los elimina de la lista de los que quedan por salir. Si hay casillas
     * libres, nos genera una fila aleatoria donde meter el zombie, crea una
     * lista de filas libres, y resta la random. que ha salido. Entonces nos
     * crea un zombie, lo introduce en la lista.
     */
    public void generarZombie(int turno) {
        if (turno > getTurnosSinZombies() && getZombiesRestantes() > 0) { //Entra si los trunos segun la dificultad lo permiten, y si no quedan zombies por salir
            String nombrezombie = ("z" + turno);
            int columna = getColumnas() - 1;
            ArrayList filaslibres = new ArrayList();
            for (int i = 0; i < getFilas(); i++) {
                if (getTablero()[i][columna] == null) {
                    filaslibres.add(i);
                } // Si la casilla está libre, nos la guarda en una lista (la fila)
            }
            Random r1 = new Random();
            int zombiesrandom = r1.nextInt(filaslibres.size() + 1); //Generamos zombies aleatorios
            if (zombiesrandom <= getZombiesRestantes()) { //Si los zombies generados aleatoriamente son menores o iguales a los que quedan por salir
                setZombiesRestantes(getZombiesRestantes() - zombiesrandom); //Restamos los zombies que han salido random a los que quedan por salir
            } else { //Sinó
                while (true) {//Hacemos lo anterior hasta que salgan menos o igual zombies que los que quedan
                    zombiesrandom = r1.nextInt(filaslibres.size() + 1); // Zombies aleatorios de cantidad máxima como el número de filas libres
                    if (zombiesrandom <= getZombiesRestantes()) {//Si ya el número generado es menor a la cantidad de zombies restantes
                        setZombiesRestantes(getZombiesRestantes() - zombiesrandom);//Reducimos la cantidad de zombies restantes
                        break;//Y cortamos el bucle
                    }
                }
            }
            if (filaslibres.size() >= 0) { //Solo entrará si hay hueco para otro zombie
                for (int i = 0; i < zombiesrandom; i++) {
                    while (true) {
                        Random rand = new Random(); //Nos genera una fila aleatoria
                        int filarandom = rand.nextInt(getFilas());//Nos guarda el numero generado a un entero
                        if (filaslibres.contains(filarandom)) { //Comprueba que la que nos ha generado está libre
                            for (int j = 0; j < filaslibres.size(); j++) {
                                if (filaslibres.get(j).equals(filarandom)) {
                                    filaslibres.remove(j); //Eliminamos de la lista de filas libres, la fila que nos ha salido
                                }
                            }
                            int tipozombie = rand.nextInt(3); //Nos genera un numero aleatorio que puede ser 0 o 3
                            if (tipozombie == 0) { //Si es un 0 nos genera un zombie comun
                                ZombieComun z = new ZombieComun(filarandom, columna, turno, nombrezombie);
                                getTablero()[filarandom][columna] = z;
                                //Nos genera un zombie e imprime sus datos y lo añade al tablero
                                break;
                            } else if (tipozombie == 1) { //Si es un 1 nos genera un zombie caracubo
                                Caracubo zc = new Caracubo(filarandom, columna, turno, nombrezombie);
                                getTablero()[filarandom][columna] = zc;
                                break;
                                //Nos genera un zombie e imprime sus datos y lo añade al tablero
                            } else if (tipozombie == 2) { //Si es un 1 nos genera un zombie deportista
                                ZombieDeportista zd = new ZombieDeportista(filarandom, columna, turno, nombrezombie);
                                getTablero()[filarandom][columna] = zd;
                                break;
                            }
                        }
                    }
                }
            }
        }
    }

    /**
     * @param item
     */
    /**
     * Borra el item deseado del tablero y de su lista correspondiente
     *
     * @param item
     */
    public void eliminarItem(Item item) {
        int filaitem = item.getFila(), columnaitem = item.getColumna(); //Nos guardamos la posición del item
        tablero[filaitem][columnaitem] = null; //Lo borramos del tablero
    }

    /**
     * Nos analiza todas las casillas hasta encontrar un elemento, que si tiene
     * vida 0, lo elimina.
     */
    public void actualizarItems() {
        for (int i = 0; i < getFilas(); i++) {
            for (int j = 0; j < getColumnas(); j++) {
                if (tablero[i][j] != null) {
                    Item elemento = tablero[i][j];
                    if (elemento.getResistencia() == 0) {
                        eliminarItem(elemento);
                        if (elemento instanceof Zombie) {
                            setZombiesvivos(getZombiesvivos() - 1);
                        }
                    }
                }
            }
        }
    }

    /**
     * @param turno
     * @return Devuelve el numero de girasoles generados en un turno
     */
    /**
     * Calcula los los soles generados por los girasoles del tablero
     *
     * @param turno
     * @return Soles generados
     */
    public int actualizarGirasoles(int turno) {
        int solesNuevos = 0;
        for (int i = 0; i < getFilas(); i++) {
            for (int j = 0; j < getColumnas(); j++) {
                if (tablero[i][j] instanceof Girasol) {
                    Girasol g = (Girasol) tablero[i][j];
                    solesNuevos += g.generarSoles(turno);
                }
            }
        }
        return solesNuevos;
    }

    /**
     * Recorre el tablero en busca de lanzaguisantes, y le quita uno de vida a
     * los zombies que tenga delante.
     */
    public void actualizarLanzaGuisantes() {
        for (int i = 0; i < getFilas(); i++) {
            for (int j = 0; j < getColumnas(); j++) {
                if (tablero[i][j] instanceof LanzaGuisantes) {
                    LanzaGuisantes l1 = (LanzaGuisantes) tablero[i][j];
                    for (int k = j + 1; k < getColumnas(); k++) {
                        if (tablero[i][k] instanceof Zombie) {
                            if (tablero[i][k] instanceof ZombieComun) {
                                ZombieComun z1 = (ZombieComun) tablero[i][k];
                                z1.recibirDano();
                                actualizarItems();
                                break;
                            } else if (tablero[i][k] instanceof Caracubo) {
                                Caracubo zc = (Caracubo) tablero[i][k];
                                zc.recibirDano();
                                actualizarItems();
                                break;
                            } else if (tablero[i][k] instanceof ZombieDeportista) {
                                ZombieDeportista zd = (ZombieDeportista) tablero[i][k];
                                zd.recibirDano();
                                actualizarItems();
                                break;

                            }
                        }
                    }
                }
            }
        }
    }

    /**
     * @param turno Turno de partida
     */
    /**
     * Recorre el tablero en busca de zombies, y dependiendo de lo que encuentre
     * delante (a la izquierda), este se mueve, ataca o no hace nada.
     *
     */
    public void actualizarZombies(int turno) {
        for (int i = 0; i < getFilas(); i++) {
            for (int j = 0; j < getColumnas(); j++) { //Recorre todo el tablero
                if (tablero[i][j] instanceof Zombie) { //Si encuetra un zombie
                    if (tablero[i][j - 1] instanceof Planta) { //Y hay delante (a su izquierda), una planta
                        tablero[i][j - 1].recibirDano(); //Le ataca
                    } else if (tablero[i][j - 1] == null && tablero[i][j] instanceof ZombieComun) { //Si no hay nada delante y es un zombiecomun
                        ZombieComun z = (ZombieComun) tablero[i][j];
                        if (((turno - z.getTurnoCreacion()) % 2 == 0) && (turno - z.getTurnoCreacion() != 0)) {
                            tablero[i][j - 1] = tablero[i][j];
                            tablero[i][j] = null; //Avanza
                            tablero[i][j - 1].setColumna(j - 1);
                        }
                    } else if (tablero[i][j - 1] == null && tablero[i][j] instanceof Caracubo) { //O un zombie caracubo
                        Caracubo zc = (Caracubo) tablero[i][j];
                        if (((turno - zc.getTurnoCreacion()) % 4 == 0) && (turno - zc.getTurnoCreacion() != 0)) {
                            tablero[i][j - 1] = tablero[i][j];
                            tablero[i][j] = null; //Avanza
                            tablero[i][j - 1].setColumna(j - 1);
                        }
                    } else if (tablero[i][j - 1] == null && tablero[i][j] instanceof ZombieDeportista) { //O un zombie deportista
                        ZombieDeportista zd = (ZombieDeportista) tablero[i][j];
                        if ((turno - zd.getTurnoCreacion() != 0)) {
                            tablero[i][j - 1] = tablero[i][j];
                            tablero[i][j] = null; //Avanza
                            tablero[i][j - 1].setColumna(j - 1);
                        }
                        actualizarItems();
                    }
                }
            }
        }
    }

    /**
     * @return Un valor que indicará si ha terminado ganando, perdiendo o no ha
     * acabado la partida
     */
    /**
     * Un valor que indicará si ha terminado ganando, perdiendo o no ha acabado
     * la partida
     */
    public int finalizar() {
        for (int i = 0; i < getFilas(); i++) {
            if (tablero[i][0] instanceof Zombie) { //El jugador ha perdido la partida, un zombie ha llegado al final
                return 0;
            }
        }
        if (getZombiesvivos() <= 0) { //El jugador gana la partida, ha matado a todos los zombies
            return 1;
        }
        return 2; //La partida sigue
    }

    
    /**
     * @return recuentoPuntosPlantas
     */
    /**
     * Método encargado de recontar los puntos correspondientes por las plantas que queden vivas al
     * acabar una partida 
     */
    public int recuentoPuntos() {
        int recuentoPuntosPlantas = 0;
        for (int i = 0; i < getFilas(); i++) {
            for (int j = 0; j < getColumnas(); j++) { //Recorre todo el tablero
                Item item = tablero[i][j];
                if (item instanceof Girasol) { //Si encuetra un girasol
                    recuentoPuntosPlantas += 20;//Suma 20 puntos
                } else if (item instanceof LanzaGuisantes || item instanceof Nuez) {//El resto de elementos tienen el mismo valor
                    recuentoPuntosPlantas += 50;//Sumamos 50
                }
            }
        }
        return recuentoPuntosPlantas;
    }

}