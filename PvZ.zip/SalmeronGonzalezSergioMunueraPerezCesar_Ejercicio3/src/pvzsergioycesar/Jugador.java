/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pvzsergioycesar;

import java.io.Serializable;
import java.util.ArrayList;

/**
 * @author César Munuera Pérez y Sergio Salmerón González
 */
/**
 * Esta clase hace referencia al objeto Jugador
 */
public class Jugador implements Serializable {
    
    /**
     * Atributo donde almacenamos el nombre del jugador
     */
    public String nombre; 
    
    /**
     *Atributo donde almacenamos el DNI del jugador
     */
    public String dni;

    /**
     *Atributo donde almacenamos la dificultad de la partida jugada por el usuario
     */
    public String dificultad;

    /**
     *Atributo donde almacenamos la puntuación del usuario
     */
    public int puntuacion;

    /**
     *Atributo donde almacenamos la cantidad total de partidas jugadas por el usuario
     */
    public int partidasJugadas;

    /**
     *Atributo donde almacenamos la cantidad total de partidas gadadas por el usuario
     */
    public int partidasGanadas;

    /**
     *Atributo donde almacenamos la cantidad total de partidas perdidas por el usuario
     */
    public int partidasPerdidas;
    
    private ArrayList<String> dificultades = new ArrayList<String>();
    private ArrayList<Integer> puntosPartidas = new ArrayList<Integer>();

    /**
     *
     * @param dni DNI del jugador
     */
    public Jugador(String dni) {
        this.nombre = nombre;
        this.dni = dni;
        this.dificultad = "BAJA";
        this.puntuacion = 0;
        this.partidasJugadas = 0;
        this.partidasGanadas = 0;
        this.partidasPerdidas = 0;
    }

    /**
     * @return Array con las partidas jugadas por un usuario, obtenemos las dificultades correspondientes
     */
    public ArrayList<String> getDificultades() {
        return this.dificultades;
    }
    
    /**
     * @param dificultad Añade las dificultades a las que juega cada nueva partida el usuario
     */
    /**
     *Añade las dificultades a las que juega cada nueva partida el usuario
     */
    public void addDificultad(String dificultad) {
        this.dificultades.add(dificultad);
    }
    
    /**
     * @return Array con los puntos de las partidas jugadas por los usuarios, nos devuelve estos puntos
     */
    public ArrayList<Integer> getPuntosPartida() {
        return this.puntosPartidas;
    }
    
    /**
     * @param puntos Añade los puntos al array, cuando el usuario gana la partida
     */
    /**
     *Añade los puntos al array, cuando el usuario gana la partida
     */
    public void addPuntos(int puntos) {
        this.puntosPartidas.add(puntos);
    }
    
    /**
     * @return Nombre del jugador
     */
    public String getNombre() {
        return nombre;
    }

    /**
     * @param nombre Introduce el nombre del jugador
     */
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    /**
     * @return Obtenemos el DNI del jugador
     */
    public String getDni() {
        return dni;
    }

    /**
     * @param dni Introducimos el DNI del jugador
     */
    public void setDni(String dni) {
        this.dni = dni;
    }

    /**
     * @return Obtenemos la puntuación del jugador
     */
    public int getPuntuacion() {
        return puntuacion;
    }
    
    /**
     * @param puntos Introducimos la puntuación del jugador, sumando a la cantidad existente
     */
    /**
     *Introducimos la puntuación del jugador, sumando a la cantidad existente
     */
    public void addPuntuacion(int puntos){
        this.puntuacion += puntos;
    }

    /**
     * @param puntuacion Introduce de golpe, sobreescribiendo, la puntuación del jugador
     */
    public void setPuntuacion(int puntuacion) {
        this.puntuacion = puntuacion;
    }

    /**
     * @return Obtenemos la dificultad del jugador
     */
    public String getDificultad() {
        return dificultad;
    }

    /**
     * @param dificultad Introducimos la dificultad jugada
     */
    public void setDificultad(String dificultad) {
        this.dificultad = dificultad;
    }

    /**
     * @return Obtenemos las partidas jugadas del jugador
     */
    public int getPartidasJugadas() {
        return partidasJugadas;
    }

    /**
     * @param partidasJugadas Introducimos las partidas jugadas por el jugador, sobreescribiendo
     */
    public void setPartidasJugadas(int partidasJugadas) {
        this.partidasJugadas = partidasJugadas;
    }
    
    /**
     *Introducimos una partida jugada por el jugador, al acabar la misma
     */
    public void addPartidaJugada(){
        this.partidasJugadas += 1;
    }
    
    /**
     *Introducimos una partida ganada por el jugador, al acabar la misma
     */
    public void addPartidaGanada(){
        this.partidasGanadas += 1;
    }
    
    /**
     *Introducimos una partida perdida por el jugador, al acabar la misma
     */
    public void addPartidaPerdida(){
        this.partidasPerdidas += 1;
    }

    /**
     * @return Obtenemos las partidas ganadas del jugador
     */
    public int getPartidasGanadas() {
        return partidasGanadas;
    }

    /**
     * @param partidasGanadas Introducimos las partidas ganadas, pero pisando la cifra anterior
     */
    public void setPartidasGanadas(int partidasGanadas) {
        this.partidasGanadas = partidasGanadas;
    }

    /**
     * @return Obtenemos las partidas perdidas del jugador
     */
    public int getPartidasPerdidas() {
        return partidasPerdidas;
    }

    /**
     * @param partidasPerdidas Introducimos las partidas perdidas por el jugador
     */
    public void setPartidasPerdidas(int partidasPerdidas) {
        this.partidasPerdidas = partidasPerdidas;
    }
 
}