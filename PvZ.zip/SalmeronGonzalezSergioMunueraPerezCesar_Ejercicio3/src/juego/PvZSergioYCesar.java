/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package juego;

import clasesjframe.Menu1JFrame;

/**
 * @author César Munuera Pérez y Sergio Salmerón González
 */
/**
 * Esta clase es la Main Classs
 */
public class PvZSergioYCesar {

    /**
     * Mediante esta clase, podremos ejecutar el juego
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Menu1JFrame m1 = new Menu1JFrame();
        m1.setVisible(true);
    }
}